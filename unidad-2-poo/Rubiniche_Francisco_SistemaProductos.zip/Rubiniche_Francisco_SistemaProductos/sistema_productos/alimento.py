from producto import Producto


class Alimento(Producto):
    def __init__(self, nombre, precio, stock, vencimiento):
        super().__init__(nombre, precio, stock)
        self.vencimiento = vencimiento

    def mostrar_datos(self):
        print(
            f"{super().mostrar_datos()} | Tipo: Alimento "
            f"| Vencimiento: {self.vencimiento}"
        )

    def calcular_precio_final(self):
        return self.precio * 0.90 
