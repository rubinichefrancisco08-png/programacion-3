from producto import Producto


class Electronico(Producto):
    def __init__(self, nombre, precio, stock, garantia):
        super().__init__(nombre, precio, stock)
        self.garantia = garantia

    def mostrar_datos(self):
        print(
            f"{super().mostrar_datos()} | Tipo: Electrónico "
            f"| Garantía: {self.garantia}"
        )

    def calcular_precio_final(self):
        return self.precio * 1.05 
