class Producto:
    def __init__(self, nombre, precio, stock):
        self.nombre = nombre
        self.precio = precio
        self.__stock = stock  

    def get_stock(self):
        return self.__stock

    def set_stock(self, nuevo_stock):
        if nuevo_stock >= 0:
            self.__stock = nuevo_stock
        else:
            print("El stock no puede ser negativo.")

    def vender(self, cantidad):
        if cantidad <= 0:
            print("La cantidad a vender debe ser mayor que cero.")
            

        if cantidad <= self.__stock:
            self.__stock -= cantidad
            print(f"Venta realizada: {cantidad} unidad(es) de {self.nombre}.")
            
        else:
            print(f"No hay stock suficiente de {self.nombre}.")
            

    def reponer(self, cantidad):
        if cantidad > 0:
            self.__stock += cantidad
            print(f"Se repusieron {cantidad} unidad(es) de {self.nombre}.")
            
        else:
            print("La cantidad a reponer debe ser mayor que cero.")
            

    def mostrar_datos(self):
            print(
                f"Nombre: {self.nombre} | Precio: ${self.precio:,.2f} "
                f"| Stock: {self.get_stock()}"
            )

    def calcular_precio_final(self):
        return self.precio
