from producto import Producto
from alimento import Alimento
from electronico import Electronico
from ropa import Ropa

# EJERCICIO 1:
leche = Alimento("Leche", 2000, 20, "15/11/2026")
notebook = Electronico("Notebook", 800000, 5, "12 meses")
cuaderno = Producto("Cuaderno", 5000, 30)

productos = [leche, notebook, cuaderno]

print("\n========== PRECIOS FINALES ==========")
for producto in productos:
    print(f"{producto.nombre}: ${producto.calcular_precio_final():,.2f}")


# EJERCICIO 2: 
remera = Ropa("Remera", 12000, 10, "M", "Remera")
pantalon = Ropa("Pantalón", 25000, 8, "42", "Pantalón")


productos = [leche, notebook, cuaderno, remera, pantalon]


# EJERCICIO 3:
print("\n========== PRUEBAS DE STOCK ==========")

print("\nVenta válida:")
print("Stock antes:", leche.get_stock())
leche.vender(5)
print("Stock después:", leche.get_stock())

print("\nVenta con stock insuficiente:")
print("Stock antes:", notebook.get_stock())
notebook.vender(10)
print("Stock después:", notebook.get_stock())

print("\nReposición:")
print("Stock antes:", cuaderno.get_stock())
cuaderno.reponer(10)
print("Stock después:", cuaderno.get_stock())



print("\n========== LISTADO COMPLETO ==========")
for producto in productos:
    print(
        f"Nombre: {producto.nombre} | "
        f"Tipo: {type(producto).__name__} | "
        f"Stock: {producto.get_stock()} | "
        f"Precio final: ${producto.calcular_precio_final():,.2f}"
    )



print("\n========== VALOR DEL INVENTARIO ==========")
total_inventario = 0

for producto in productos:
    valor_producto = producto.get_stock() * producto.calcular_precio_final()
    total_inventario += valor_producto
    print(
        f"{producto.nombre}: {producto.get_stock()} x "
        f"${producto.calcular_precio_final():,.2f} = ${valor_producto:,.2f}"
    )

print(f"Valor total del inventario: ${total_inventario:,.2f}")


print("\n========== PRODUCTO DE MAYOR PRECIO ==========")
producto_mas_caro = productos[0]

for producto in productos:
    if producto.calcular_precio_final() > producto_mas_caro.calcular_precio_final():
        producto_mas_caro = producto

print(
    f"El producto más caro es {producto_mas_caro.nombre}, "
    f"con un precio final de ${producto_mas_caro.calcular_precio_final():,.2f}."
)

# 1. ¿Qué diferencia hay entre heredar un método y sobrescribirlo?
# Heredar es cuando una clase hija recibe un método de la clase padre
# y puede utilizarlo. En cambio, sobrescribir es cuando la clase hija
# vuelve a escribir ese método para que haga algo diferente.

# 2. ¿Por qué el mismo for puede invocar calcular_precio_final()
# en todos los productos sin usar if por tipo?
# Porque se usa el polimorfismo. Esto permite que todos los productos
# llamen al mismo método, pero cada uno lo ejecuta de acuerdo con
# su propia clase.

# 3. ¿Qué inicializa super().__init__(...) en cada clase hija?
# Se encarga de llamar al constructor de la clase padre (Producto)
# para inicializar los datos que comparten todas las clases,
# como el nombre, el precio y el stock.

# 4. ¿Qué diferencia hay entre vender(5), reponer(5) y set_stock(5)?
# vender(5): resta cinco unidades del stock, siempre que haya suficientes.
# reponer(5): suma cinco unidades al stock.
# set_stock(5): cambia el stock actual y lo deja directamente en cinco.

# 5. Identificá una línea que demuestre encapsulamiento,
# herencia y polimorfismo.
# Encapsulamiento: self.__stock = stock, porque el stock está protegido
# dentro de la clase Producto.
# Herencia: class Alimento(Producto), porque Alimento hereda las
# características de Producto.
# Polimorfismo: producto.calcular_precio_final(), porque cada producto
# puede ejecutar ese método de una manera diferente.

# 6. ¿Qué responsabilidad tiene main.py y por qué separamos
# las clases en distintos archivos?
# main.py es donde se pone en funcionamiento el programa.
# Ahí se crean los productos, se guardan en una lista, se prueban
# los métodos y se muestran los resultados.
# Separamos las clases en distintos archivos para tener el código
# más ordenado, que sea fácil de entender y que podamos modificar
# cada parte sin tener que cambiar todo el programa.
